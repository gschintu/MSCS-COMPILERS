int
main (int x) {
    if (x < 15)
        return 88;
    return 21;
}
