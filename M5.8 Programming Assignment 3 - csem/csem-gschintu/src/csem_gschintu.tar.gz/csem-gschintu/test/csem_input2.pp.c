



int main()
{

  int a, c;
  double b, d;

  a = 3;
  b = 4;
  c = 5;
  d = 6;

  print("%d %3.2f %d %3.2f\n", a, b, c, d);

  return 0;
}
